var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var api_exports = {};
__export(api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_exports);
var import_serverless_http = __toESM(require("serverless-http"), 1);
var import_url = require("url");
var import_path = require("path");
var import_dotenv = __toESM(require("dotenv"), 1);
var import_express = __toESM(require("express"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_mongoose = __toESM(require("mongoose"), 1);
var import_User = require("../../models/User.js");
var import_Shelter = require("../../models/Shelter.js");
var import_nodemailer = __toESM(require("nodemailer"), 1);
import_dotenv.default.config();
const app = (0, import_express.default)();
app.use((0, import_cors.default)());
app.use(import_express.default.json());
const MONGODB_URI = process.env.MONGODB_URI;
let isConnected = false;
async function connectToDatabase() {
  if (isConnected && import_mongoose.default.connection.readyState === 1) return;
  if (!MONGODB_URI) {
    throw new Error("MONGODB_URI is missing in Netlify Environment Variables");
  }
  try {
    console.log("Connecting to MongoDB Atlas...");
    await import_mongoose.default.connect(MONGODB_URI, {
      serverSelectionTimeoutMS: 15e3
      // Shorter timeout for serverless
    });
    isConnected = true;
    console.log("Connected to MongoDB Atlas");
  } catch (err) {
    console.error("MongoDB connection error:", err);
    throw err;
  }
}
const dbMiddleware = async (req, res, next) => {
  try {
    await connectToDatabase();
    next();
  } catch (err) {
    res.status(500).json({
      message: `Database Connection Error: ${err.message}. Please ensure MONGODB_URI is set in Netlify settings.`
    });
  }
};
app.use(dbMiddleware);
const router = import_express.default.Router();
router.get("/health", (req, res) => {
  res.json({
    status: "ok",
    message: "SafeEvac API is live",
    environment: process.env.NODE_ENV || "production",
    time: (/* @__PURE__ */ new Date()).toISOString()
  });
});
router.post("/signup", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const existingUser = await import_User.User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: "User already exists" });
    const user = new import_User.User({ name, email, password });
    await user.save();
    res.status(201).json({ message: "User created successfully" });
  } catch (error) {
    res.status(500).json({ message: `Signup Error: ${error.message}` });
  }
});
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await import_User.User.findOne({ email });
    if (!user || user.password !== password) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    res.json({ message: "Login successful", user: { name: user.name, email: user.email } });
  } catch (error) {
    res.status(500).json({ message: `Login Error: ${error.message}` });
  }
});
router.get("/profile/:email", async (req, res) => {
  try {
    const user = await import_User.User.findOne({ email: req.params.email });
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: "Error fetching profile" });
  }
});
router.put("/profile/:email", async (req, res) => {
  try {
    const updatedUser = await import_User.User.findOneAndUpdate(
      { email: req.params.email },
      req.body,
      { new: true }
    );
    res.json(updatedUser);
  } catch (error) {
    res.status(500).json({ message: "Error updating profile" });
  }
});
router.get("/shelters", async (req, res) => {
  try {
    const shelters = await import_Shelter.Shelter.find();
    res.json(shelters);
  } catch (error) {
    res.status(500).json({ message: "Error fetching shelters" });
  }
});
router.post("/sos", async (req, res) => {
  const { email, location, locationName } = req.body;
  try {
    const user = await import_User.User.findOne({ email });
    if (!user || !user.emergencyEmail) return res.status(404).json({ message: "Emergency contact not set" });
    const transporter = import_nodemailer.default.createTransport({
      service: "gmail",
      auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS }
    });
    const mapLink = `https://www.google.com/maps?q=${location.lat},${location.lng}`;
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: user.emergencyEmail,
      subject: `\u{1F6A8} SOS ALERT: ${user.name} needs help!`,
      text: `EMERGENCY ALERT

${user.name} has triggered an SOS.
Last known location: ${locationName || "Unknown"}
Map Link: ${mapLink}`
    });
    res.json({ message: "SOS alert sent to your emergency contact!" });
  } catch (error) {
    res.status(500).json({ message: "Failed to send SOS" });
  }
});
app.use("/.netlify/functions/api", router);
app.use("/api", router);
app.use("/", router);
const handler = (0, import_serverless_http.default)(app);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
